package jUnitTestngPackage;

public class jUnitFunctions {
	public int addnum(int a,int b) {
		return a+b;
	}
	public String addstring(String s1,String s2) {
		return s1+s2;
	}

}
